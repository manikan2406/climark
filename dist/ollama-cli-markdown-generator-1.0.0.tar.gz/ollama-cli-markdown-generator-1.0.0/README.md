# Ollama CLI

A CLI tool for generating markdown document for Python projects using Ollama LLM.

## Installation

```bash
pip install .
